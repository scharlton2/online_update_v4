#ifndef ERROR_MACROS_H
#define ERROR_MACROS_H

#define RETURN_IF_ERR if (ier != 0) {return ier;}

#endif // ERROR_MACROS_H
